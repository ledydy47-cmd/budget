import io
import re
import subprocess
import sys
import shutil
import time
import json
import uuid
import zipfile
from pathlib import Path
from flask import Flask, request, jsonify, send_file, render_template, abort

BASE_DIR = Path(__file__).parent.resolve()

PROJECTS = {
    "envelope": {
        "title": "Конверты на iPhone",
        "script": "generate_envelope.py",
        "output_dir": "output_envelope",
        "slots": [
            {"key": "slide1_bg", "label": "Фон — слайд 1 (вступление)",
             "path": "photos/envelope/slide1/background.jpg"},
            {"key": "slides23_bg", "label": "Фон — слайды 2-3 (конверты)",
             "path": "photos/envelope/slides_2_3/background.jpg"},
            {"key": "goal_bg", "label": "Фон — слайд 4 (цель)",
             "path": "photos/envelope/goal/bg.jpg"},
            {"key": "bot_screenshot", "label": "Скриншот профиля бота",
             "path": "photos/envelope/bot/telegram_profile.png"}
        ],
        "slides_config": None,
    },
    "budget": {
        "title": "Бюджет 72 000 ₽",
        "script": "generate_slides.py",
        "output_dir": "output",
        "slots": [
            {"key": "slide1_bg", "label": "Фон — слайды 1 и 11 (текст)",
             "path": "photos/slide1/background.png"},
            {"key": "cards_bg", "label": "Фон — слайды 2-10 (карточки)",
             "path": "photos/slides_2_11/background.png"}
        ],
        "slides_config": "budget_profile.json",
    },
    "dubai": {
        "title": "Дубай (конверты)",
        "script": "generate_dubai.py",
        "output_dir": "output_dubai",
        "slots": [
            {"key": "group_a_bg", "label": "Фон — слайды 1, 2, 6",
             "path": "photos/dubai/group_a/background.jpg"},
            {"key": "group_b_bg", "label": "Фон — слайды 3, 4, 5",
             "path": "photos/dubai/group_b/background.jpg"},
            {"key": "bot_screenshot", "label": "Скриншот профиля бота (слайд 6)",
             "path": "photos/dubai/bot/telegram_profile.png"}
        ],
        "slides_config": "dubai_slides.json",
    },
    "hook": {
        "title": "Хук-карусель (охватный формат)",
        "script": "generate_hook.py",
        "output_dir": "output_hook",
        "slots": [
            {"key": "slide1_photo", "label": "Фото — слайд 1 (девушка в лифте)",
             "path": "photos/hook/slide1.jpg"},
            {"key": "slide2_photo", "label": "Фото — слайд 2 (трекер калорий)",
             "path": "photos/hook/slide2.jpg"},
            {"key": "slide3_photo", "label": "Фото — слайд 3 (шаги)",
             "path": "photos/hook/slide3.jpg"},
            {"key": "slide4_photo", "label": "Фото — слайд 4 (план тренировок)",
             "path": "photos/hook/slide4.jpg"}
        ],
        "slides_config": "hook_slides.json",
    },
    "nedelya_week": {
        "title": "Неделя трат (карусель)",
        "script": "generate_nedelya_week.py",
        "output_dir": "output_nedelya_week",
        "slots": [],
        "slides_config": "nedelya_week_slides.json",
    },
    "karusel_3": {
        "title": "Карусель 3 (бюджет vs парень)",
        "script": "generate_karusel_3.py",
        "output_dir": "output_karusel_3",
        "slots": [],
        "slides_config": "karusel_3_slides.json",
    },
    "tiktok_couple": {
        "title": "TikTok: я vs парень",
        "script": "generate_tiktok_couple.py",
        "output_dir": "output_tiktok_couple",
        "slots": [],
        "slides_config": "tiktok_couple_slides.json",
    },
    "couple_factory": {
        "title": "Бюджет пары",
        "kind": "couple",
        "script": "generate_couple_carousel.py",
        "output_dir": "couple_inbox",
        "slots": [],
        "slides_config": None,
    },
    "place_board": {
        "title": "Расставить плашки",
        "kind": "place",
        "script": "generate_couple_carousel.py",
        "output_dir": "place_inbox",
        "slots": [],
        "slides_config": None,
    },
    "expenses": {
        "title": "Расходы (6 слайдов)",
        "script": "generate_expenses.py",
        "output_dir": "output_expenses",
        "slots": [
            {"key": "slide1_bg", "label": "Фон — слайд 1 (текст)",
             "path": "photos/slide1/background.png"},
            {"key": "cards_bg", "label": "Фон — слайды 2-4 (карточки)",
             "path": "photos/slides_2_11/background.png"}
        ],
        "slides_config": None,
    },
}

SAVED_DIR = BASE_DIR / "saved_carousels"
SAVED_DIR.mkdir(exist_ok=True)

COUPLE_INBOX = BASE_DIR / "couple_inbox"
COUPLE_INBOX.mkdir(exist_ok=True)
PLACE_INBOX = BASE_DIR / "place_inbox"
PLACE_INBOX.mkdir(exist_ok=True)
COUPLE_ID_RE = re.compile(r"[a-z0-9][a-z0-9-]{0,40}")
COUPLE_OUTPUT_RE = re.compile(r"slide-\d{2}\.png|caption\.txt")

LATEST_OUTPUT = {}

BUDGET_PROFILE_NAME = "budget_profile.json"
DEFAULT_BUDGET_TITLE = PROJECTS["budget"]["title"]


def format_money_ru(value: int) -> str:
    return f"{int(value):,}".replace(",", " ")


def budget_income():
    target = BASE_DIR / BUDGET_PROFILE_NAME
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    income = data.get("income")
    if isinstance(income, (int, float)):
        return int(income)
    return None


def refresh_project_titles() -> None:
    """Название вкладки бюджета берём из budget_profile.json."""
    project = PROJECTS.get("budget")
    if not project:
        return
    income = budget_income()
    project["title"] = f"Бюджет {format_money_ru(income)} ₽" if income else DEFAULT_BUDGET_TITLE


GOAL_PHOTO_DIR = BASE_DIR / "photos" / "goal"
GOAL_PHOTO_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,80}\.(?:png|jpe?g|webp)", re.IGNORECASE)


def budget_goal_photo():
    """Имя картинки мечты из budget_profile.json (или None)."""
    target = BASE_DIR / BUDGET_PROFILE_NAME
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    name = data.get("goal_photo")
    if isinstance(name, str) and GOAL_PHOTO_RE.fullmatch(name):
        return name
    return None


refresh_project_titles()

PROJECTS = {k: v for k, v in PROJECTS.items() if k == "budget"}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 80 * 1024 * 1024


def get_project(key):
    project = PROJECTS.get(key)
    if not project:
        abort(404, "Проект не найден")
    return project


def couple_dir(raw_id):
    if not raw_id or not COUPLE_ID_RE.fullmatch(raw_id):
        abort(400, "Некорректный id карусели")
    path = (COUPLE_INBOX / raw_id).resolve()
    if path.parent != COUPLE_INBOX.resolve() or not path.is_dir():
        abort(404, "Карусель не найдена")
    return path


def read_json(path: Path):
    if not path.is_file():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def couple_summary(folder: Path):
    brief = read_json(folder / "brief.json") or {}
    slides = brief.get("slides") or []
    photos = folder / "photos"
    image_ext = {".png", ".jpg", ".jpeg", ".webp"}
    photo_count = 0
    if photos.is_dir():
        photo_count = sum(1 for path in photos.iterdir() if path.suffix.lower() in image_ext)
    return {
        "id": folder.name,
        "title": brief.get("title") or folder.name,
        "hasBrief": (folder / "brief.json").is_file(),
        "hasLayout": (folder / "layout.json").is_file(),
        "slideCount": len(slides),
        "photoCount": photo_count,
    }


def slot_path(project, slot_key):
    for slot in project["slots"]:
        if slot["key"] == slot_key:
            return BASE_DIR / slot["path"]
    abort(404, "Слот не найден")


@app.route("/")
def index():
    refresh_project_titles()
    return render_template("index.html", projects=PROJECTS)


@app.route("/api/upload", methods=["POST"])
def upload():
    project_key = request.form.get("project")
    slot_key = request.form.get("slot")
    file = request.files.get("file")
    if not (project_key and slot_key and file):
        return jsonify({"ok": False, "error": "Не хватает данных"}), 400

    project = get_project(project_key)
    target = slot_path(project, slot_key)
    target.parent.mkdir(parents=True, exist_ok=True)
    file.save(target)
    return jsonify({"ok": True})


@app.route("/api/photo/<project_key>/<slot_key>")
def get_photo(project_key, slot_key):
    project = get_project(project_key)
    target = slot_path(project, slot_key)
    if not target.exists():
        abort(404)
    return send_file(target)


@app.route("/api/slides/<project_key>", methods=["GET"])
def get_slides_config(project_key):
    project = get_project(project_key)
    config_name = project.get("slides_config")
    if not config_name:
        return jsonify({"ok": False, "error": "У этого проекта нет редактируемого текста"}), 404
    target = BASE_DIR / config_name
    if not target.exists():
        return jsonify({"ok": False, "error": "Файл конфигурации не найден"}), 404
    return jsonify({"ok": True, "content": target.read_text(encoding="utf-8")})


@app.route("/api/slides/<project_key>", methods=["POST"])
def save_slides_config(project_key):
    project = get_project(project_key)
    config_name = project.get("slides_config")
    if not config_name:
        return jsonify({"ok": False, "error": "У этого проекта нет редактируемого текста"}), 404

    data = request.get_json()
    content = data.get("content", "")
    try:
        json.loads(content)
    except json.JSONDecodeError as e:
        return jsonify({"ok": False, "error": f"Ошибка в формате JSON: {e}"}), 400

    target = BASE_DIR / config_name
    target.write_text(content, encoding="utf-8")
    refresh_project_titles()
    return jsonify({"ok": True, "title": project.get("title")})


@app.route("/api/goal-photo/<project_key>", methods=["POST"])
def upload_goal_photo(project_key):
    get_project(project_key)
    file = request.files.get("file")
    if file is None or not file.filename:
        return jsonify({"ok": False, "error": "Файл не выбран"}), 400
    ext = Path(file.filename).suffix.lower()
    if ext not in {".png", ".jpg", ".jpeg", ".webp"}:
        return jsonify({"ok": False, "error": "Нужен PNG, JPG или WebP"}), 400
    GOAL_PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    name = f"goal_{int(time.time())}{ext}"
    file.save(GOAL_PHOTO_DIR / name)
    return jsonify({
        "ok": True,
        "file": name,
        "url": f"/api/goal-photo/{project_key}?file={name}&t={int(time.time())}",
    })


@app.route("/api/goal-photo/<project_key>")
def get_goal_photo(project_key):
    get_project(project_key)
    name = request.args.get("file")
    if not name:
        name = budget_goal_photo()
    if not name and (GOAL_PHOTO_DIR / "photo.jpg").is_file():
        name = "photo.jpg"
    if not name or not GOAL_PHOTO_RE.fullmatch(name):
        abort(404)
    target = GOAL_PHOTO_DIR / name
    if not target.is_file():
        abort(404)
    return send_file(target)


@app.route("/api/generate", methods=["POST"])
def generate():
    data = request.get_json()
    project_key = data.get("project")
    project = get_project(project_key)

    if project.get("kind") == "couple":
        return jsonify({
            "ok": False,
            "error": "Выбери папку на вкладке «Бюджет пары» и нажми «Собрать карусель»",
        }), 400

    if project.get("kind") == "place":
        return jsonify({
            "ok": False,
            "error": "На вкладке «Расставить плашки» нажми «Собрать PNG»",
        }), 400

    cmd = [sys.executable, project["script"]]

    if project_key in ("budget", "expenses", "tiktok_couple", "nedelya_week", "karusel_3"):
        version_stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
        gen_out_dir = BASE_DIR / project["output_dir"] / version_stamp
        gen_out_dir.mkdir(parents=True, exist_ok=True)
        cmd += ["--out-dir", str(gen_out_dir)]
        if project_key == "tiktok_couple":
            cmd += ["--project-dir", "/Users/diana/Downloads/project (2)"]
        if project_key == "nedelya_week":
            cmd += ["--project-dir", "/Users/diana/Downloads/карусель 2"]
        if project_key == "karusel_3":
            cmd += ["--project-dir", "/Users/diana/Downloads/карусель 3"]
        if project_key == "budget" and project.get("slides_config"):
            cmd += ["--profile", str(BASE_DIR / project["slides_config"])]
            goal_photo = budget_goal_photo()
            if goal_photo:
                cmd += ["--photo-goal", str(GOAL_PHOTO_DIR / goal_photo)]
    else:
        gen_out_dir = BASE_DIR / project["output_dir"]

    result = subprocess.run(
        cmd,
        cwd=BASE_DIR,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        return jsonify({
            "ok": False,
            "error": result.stderr[-3000:] or "Неизвестная ошибка при генерации",
        }), 500

    if project_key in ("budget", "expenses", "tiktok_couple", "nedelya_week", "karusel_3"):
        LATEST_OUTPUT[project_key] = gen_out_dir

    files = sorted(f.name for f in gen_out_dir.glob("*.png"))
    stamp = int(time.time())
    slides = [f"/api/thumb/{project_key}/{name}?t={stamp}" for name in files]

    return jsonify({"ok": True, "slides": slides})


@app.route("/api/output/<project_key>/<filename>")
def get_output(project_key, filename):
    project = get_project(project_key)
    base = LATEST_OUTPUT.get(project_key, BASE_DIR / project["output_dir"])
    target = base / filename
    if not target.exists():
        abort(404)
    return send_file(target)


@app.route("/api/thumb/<project_key>/<filename>")
def get_thumb(project_key, filename):
    project = get_project(project_key)
    base = LATEST_OUTPUT.get(project_key, BASE_DIR / project["output_dir"])
    src = base / filename
    if not src.exists():
        abort(404)
    thumbs = base / ".thumbs"
    thumbs.mkdir(exist_ok=True)
    dst = thumbs / (src.stem + ".jpg")
    if not dst.exists() or dst.stat().st_mtime < src.stat().st_mtime:
        try:
            from PIL import Image
            with Image.open(src) as im:
                im = im.convert("RGB")
                im.thumbnail((540, 960), Image.LANCZOS)
                im.save(dst, "JPEG", quality=82, optimize=True)
        except Exception:
            return send_file(src)
    return send_file(dst, mimetype="image/jpeg")


@app.route("/api/download/<project_key>")
def download_zip(project_key):
    project = get_project(project_key)
    base = LATEST_OUTPUT.get(project_key, BASE_DIR / project["output_dir"])
    files = sorted(base.glob("slide_*.png"))
    if not files:
        abort(404)
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            num = re.sub(r"\D", "", path.stem) or "0"
            archive.write(path, f"{int(num)}.png")
    buffer.seek(0)
    return send_file(
        buffer,
        mimetype="application/zip",
        as_attachment=True,
        download_name=f"{project_key}_slides.zip",
    )


@app.route("/api/save", methods=["POST"])
def save():
    data = request.get_json()
    project_key = data.get("project")
    project = get_project(project_key)

    out_dir = LATEST_OUTPUT.get(project_key, BASE_DIR / project["output_dir"])
    if not out_dir.exists() or not any(out_dir.glob("*.png")):
        return jsonify({"ok": False, "error": "Нет сгенерированных слайдов для сохранения"}), 400

    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    dest_dir = SAVED_DIR / f"{project_key}_{stamp}"
    shutil.copytree(out_dir, dest_dir)

    return jsonify({"ok": True, "path": str(dest_dir)})


def couple_slide_by_slot(brief, slot):
    for slide in brief.get("slides") or []:
        photo = slide.get("photo") or ""
        if Path(photo).stem == slot:
            return slide
    return None


@app.route("/api/couple/inbox")
def couple_inbox():
    folders = []
    if COUPLE_INBOX.is_dir():
        for folder in sorted(p for p in COUPLE_INBOX.iterdir() if p.is_dir()):
            if (folder / "brief.json").is_file():
                folders.append(couple_summary(folder))
    return jsonify({"ok": True, "folders": folders})


@app.route("/api/couple/<couple_id>")
def couple_detail(couple_id):
    folder = couple_dir(couple_id)
    brief = read_json(folder / "brief.json")
    if brief is None:
        return jsonify({"ok": False, "error": "Нет brief.json"}), 404
    layout = read_json(folder / "layout.json")
    slides = []
    for slide in brief.get("slides") or []:
        photo = slide.get("photo") or ""
        slot = Path(photo).stem
        photo_path = folder / photo
        slides.append({
            "slot": slot,
            "label": slide.get("label") or slot,
            "photoPrompt": slide.get("photo_prompt") or "",
            "freeZone": slide.get("free_zone") or "",
            "hasPhoto": photo_path.is_file(),
        })
    caption = (layout or {}).get("caption") or brief.get("caption") or {}
    return jsonify({
        "ok": True,
        "id": couple_id,
        "title": brief.get("title") or couple_id,
        "scenario": brief.get("scenario") or "",
        "caption": caption,
        "hasLayout": layout is not None,
        "slides": slides,
    })


@app.route("/api/couple/upload", methods=["POST"])
def couple_upload():
    couple_id = request.form.get("id")
    slot = request.form.get("slot")
    file = request.files.get("file")
    if not (couple_id and slot and file):
        return jsonify({"ok": False, "error": "Не хватает данных"}), 400
    if not re.fullmatch(r"\d{2}", slot):
        return jsonify({"ok": False, "error": "Слот должен быть 01, 02, …"}), 400

    folder = couple_dir(couple_id)
    brief = read_json(folder / "brief.json") or {}
    slide = couple_slide_by_slot(brief, slot)
    if not slide:
        return jsonify({"ok": False, "error": "Такого слайда нет в brief.json"}), 404

    target = folder / slide["photo"]
    folder_root = str(folder.resolve()) + "/"
    if not str(target.resolve()).startswith(folder_root):
        abort(400)
    target.parent.mkdir(parents=True, exist_ok=True)
    file.save(target)
    return jsonify({"ok": True})


@app.route("/api/couple/photo/<couple_id>/<slot>")
def couple_photo(couple_id, slot):
    folder = couple_dir(couple_id)
    brief = read_json(folder / "brief.json") or {}
    slide = couple_slide_by_slot(brief, slot)
    if not slide:
        abort(404)
    target = folder / slide["photo"]
    if not target.is_file():
        abort(404)
    return send_file(target)


@app.route("/api/couple/generate", methods=["POST"])
def couple_generate():
    data = request.get_json() or {}
    couple_id = data.get("id")
    folder = couple_dir(couple_id)
    if not (folder / "layout.json").is_file():
        return jsonify({"ok": False, "error": "жду расстановку плашек"}), 400

    cmd = [sys.executable, "generate_couple_carousel.py", "--dir", str(folder)]
    result = subprocess.run(cmd, cwd=BASE_DIR, capture_output=True, text=True)
    if result.returncode != 0:
        message = (result.stderr or result.stdout or "Неизвестная ошибка").strip()
        return jsonify({"ok": False, "error": message[-3000:]}), 500

    out_dir = folder / "output"
    LATEST_OUTPUT[f"couple:{couple_id}"] = out_dir
    files = sorted(f.name for f in out_dir.glob("slide-*.png"))
    stamp = int(time.time())
    slides = [f"/api/couple/output/{couple_id}/{name}?t={stamp}" for name in files]
    caption = (out_dir / "caption.txt").read_text(encoding="utf-8") if (out_dir / "caption.txt").is_file() else ""
    return jsonify({"ok": True, "slides": slides, "caption": caption})


@app.route("/api/couple/output/<couple_id>/<filename>")
def couple_output(couple_id, filename):
    if not COUPLE_OUTPUT_RE.fullmatch(filename):
        abort(404)
    folder = couple_dir(couple_id)
    target = folder / "output" / filename
    if not target.is_file():
        abort(404)
    return send_file(target)


@app.route("/api/place/render", methods=["POST"])
def place_render():
    raw = request.form.get("layout")
    if not raw:
        return jsonify({"ok": False, "error": "Нет раскладки"}), 400
    try:
        layout = json.loads(raw)
    except json.JSONDecodeError as error:
        return jsonify({"ok": False, "error": f"Ошибка в раскладке: {error}"}), 400

    slides = layout.get("slides") or []
    if not slides:
        return jsonify({"ok": False, "error": "Нет слайдов"}), 400

    files = []
    index = 0
    while True:
        upload = request.files.get(f"photo_{index}")
        if upload is None:
            break
        files.append(upload)
        index += 1
    if len(files) != len(slides):
        return jsonify({"ok": False, "error": "Число фото и слайдов не совпало"}), 400

    folder = PLACE_INBOX / uuid.uuid4().hex[:12]
    photos = folder / "photos"
    photos.mkdir(parents=True)
    image_ext = {".png", ".jpg", ".jpeg", ".webp"}
    for slide_index, (slide, upload) in enumerate(zip(slides, files), start=1):
        ext = Path(upload.filename or "").suffix.lower()
        if ext not in image_ext:
            ext = ".png"
        name = f"{slide_index:02d}{ext}"
        upload.save(photos / name)
        slide["photo"] = f"photos/{name}"
        slide["watermark"] = False

    from generate_couple_carousel import validate_layout

    try:
        validate_layout(layout)
    except ValueError as error:
        shutil.rmtree(folder, ignore_errors=True)
        return jsonify({"ok": False, "error": str(error)}), 400

    (folder / "layout.json").write_text(
        json.dumps(layout, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    cmd = [sys.executable, "generate_couple_carousel.py", "--dir", str(folder)]
    result = subprocess.run(cmd, cwd=BASE_DIR, capture_output=True, text=True)
    if result.returncode != 0:
        message = (result.stderr or result.stdout or "Неизвестная ошибка").strip()
        return jsonify({"ok": False, "error": message[-3000:]}), 500

    out_dir = folder / "output"
    names = sorted(path.name for path in out_dir.glob("slide-*.png"))
    stamp = int(time.time())
    urls = [
        f"/api/place/output/{folder.name}/{name}?t={stamp}"
        for name in names
    ]
    return jsonify({"ok": True, "id": folder.name, "slides": urls})


@app.route("/api/place/output/<place_id>/<filename>")
def place_output(place_id, filename):
    if not re.fullmatch(r"[a-f0-9]{12}", place_id):
        abort(404)
    if not re.fullmatch(r"slide-\d{2}\.png", filename):
        abort(404)
    target = PLACE_INBOX / place_id / "output" / filename
    if not target.is_file():
        abort(404)
    return send_file(target)


@app.route("/api/place/download/<place_id>")
def place_download(place_id):
    if not re.fullmatch(r"[a-f0-9]{12}", place_id):
        abort(404)
    out_dir = PLACE_INBOX / place_id / "output"
    names = sorted(path for path in out_dir.glob("slide-*.png") if path.is_file())
    if not names:
        abort(404)
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in names:
            archive.write(path, path.name)
    buffer.seek(0)
    return send_file(
        buffer,
        mimetype="application/zip",
        as_attachment=True,
        download_name="plashki.zip",
    )


if __name__ == "__main__":
    app.run(debug=True, port=5050)
