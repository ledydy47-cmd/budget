"""CLI wrapper — run: python validate_budget_profile.py profile.json"""

from budget_profile_loader import main

if __name__ == "__main__":
    main()
