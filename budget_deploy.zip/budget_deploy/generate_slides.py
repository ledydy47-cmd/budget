from pathlib import Path
from jinja2 import Template
from playwright.sync_api import sync_playwright

PHOTO_SLIDE1 = Path("photos/slide1/background.png").resolve().as_uri()
PHOTO_BOT_SCREENSHOT = Path("photos/bot/telegram_profile.png").resolve().as_uri()
PHOTO_CARDS = Path("photos/slides_2_11/background.png").resolve().as_uri()
PHOTO_GOAL = Path("photos/goal/photo.jpg").resolve().as_uri()

BRAND_NAME = "Название бота"
BRAND_EMOJI = "💸"

OUT_DIR = Path("output")
OUT_DIR.mkdir(exist_ok=True)


def plural_ru(n, one, few, many):
    n_abs = abs(n) % 100
    n1 = n_abs % 10
    if 11 <= n_abs <= 14:
        return many
    if n1 == 1:
        return one
    if 2 <= n1 <= 4:
        return few
    return many


def format_money(n):
    return f"{n:,.0f} ₽".replace(",", " ")


def make_card_data(category, emoji, spent, limit, comment, accent_color):
    remaining = limit - spent
    over_budget = remaining < 0
    ratio = spent / limit if limit > 0 else 0

    if over_budget:
        remaining_text = f"превышение на {format_money(abs(remaining))}"
        remaining_color = "#E53935"
        bar_color = "#E53935"
        percent = 100
    else:
        remaining_text = f"осталось {format_money(remaining)}"
        remaining_color = "#43A047"
        bar_color = accent_color
        percent = round(min(ratio, 1.0) * 100, 1)

    ops = comment["ops"]

    return {
        "type": "card",
        "category_name": category,
        "emoji": emoji,
        "spent_text": format_money(spent),
        "limit_text": format_money(limit),
        "remaining_text": remaining_text,
        "remaining_color": remaining_color,
        "percent": percent,
        "bar_color": bar_color,
        "ops_text": f"{ops} {plural_ru(ops, 'операция', 'операции', 'операций')}",
        "days_text": "осталось 1 день",
        "comment": comment["text"],
    }


SLIDES = [
    {"type": "text",
     "text": "Как я выживаю на зарплату\n72 000 ₽ 🥲💗"},

    {"category": "Жильё", "emoji": "🏠", "spent": 25000, "limit": 25000,
     "accent": "#D98E4B", "ops": 1,
     "comment": "Аренда съедает больше всего, квартиру мне не купить никогда 🙃"},

    {"category": "Продукты", "emoji": "🥕", "spent": 15000, "limit": 16000,
     "accent": "#FF9F43", "ops": 8,
     "comment": "Два больших закупа и вечные забеги в Пятёрочку 🛒"},

    {"category": "Кафе и доставка", "emoji": "🍕", "spent": 5000, "limit": 4000,
     "accent": "#E53935", "ops": 12,
     "comment": "Ленюсь готовить, каюсь… доставка меня погубит 💀"},

    {"category": "Маркетплейсы", "emoji": "🛍️", "spent": 4000, "limit": 3500,
     "accent": "#E53935", "ops": 6,
     "comment": "Wildberries — самая опасная кнопка в телефоне 🫠"},

    {"category": "Коммуналка и связь", "emoji": "💡", "spent": 4000, "limit": 4000,
     "accent": "#F4C430", "ops": 3,
     "comment": "Платежи, которые вечно забываю вовремя оплатить 😅"},

    {"category": "Транспорт", "emoji": "🚌", "spent": 3000, "limit": 3500,
     "accent": "#4A90D9", "ops": 5,
     "comment": "Метро + такси, когда проспала на работу 🚕"},

    {"category": "Красота", "emoji": "💅", "spent": 3000, "limit": 3000,
     "accent": "#FF6FA5", "ops": 2,
     "comment": "Маникюр раз в месяц — это святое, не трогать 💗"},

    {"category": "Подписки", "emoji": "📱", "spent": 1000, "limit": 1000,
     "accent": "#6C7AE0", "ops": 4,
     "comment": "Половину даже не помню, зачем оформила 🙃"},

    {"category": "Досуг", "emoji": "🥰", "spent": 3000, "limit": 3500,
     "accent": "#FF8C7A", "ops": 3,
     "comment": "Посиделки с подружками — без этого никак 🍷"},

    {"type": "goal",
     "goal_title": "Поездка в Сочи ✈️",
     "goal_saved": 9000,
     "goal_target": 108000,
     "income": 72000,
     "spent": 63000},

    {
        "type": "bot_outro",
        "heading": "Все конверты веду в боте\nв тг @mani_tochka_bot \U0001F430",
        "bot_screenshot_uri": PHOTO_BOT_SCREENSHOT,
        "caption": "Каждый месяц вижу, как мечта становится ближе \u2708\uFE0F\U0001F495"
    },
]


def build_render_data(slide):
    if slide.get("type") == "text":
        return {"type": "text", "bg_uri": PHOTO_SLIDE1, "text": slide["text"]}

    if slide.get("type") == "bot_outro":
        return {
            "type": "bot_outro",
            "bg_uri": slide.get("bg_uri", PHOTO_SLIDE1),
            "heading": slide["heading"],
            "bot_screenshot_uri": slide["bot_screenshot_uri"],
            "caption": slide["caption"],
        }

    if slide.get("type") == "goal":
        saved = slide["goal_saved"]
        target = slide["goal_target"]
        percent = round(saved / target * 100) if target else 0
        remaining = slide["income"] - slide["spent"]
        default_heading = (
            f"И у меня остаётся {format_money(remaining)}, которые я каждый месяц "
            f"откладываю на {slide['goal_title']} 💗"
        )
        return {
            "type": "goal",
            "bg_uri": PHOTO_SLIDE1,
            "goal_photo_uri": PHOTO_GOAL,
            "goal_heading": slide.get("goal_heading") or default_heading,
            "goal_title": slide["goal_title"],
            "goal_percent": percent,
            "goal_saved": format_money(saved),
            "goal_target": format_money(target),
            "summary_amount": format_money(remaining),
            "income_text": format_money(slide["income"]),
            "spent_text_summary": format_money(slide["spent"]),
            "bot_caption": "Это приложение, если вдруг кому интересно — бот в Telegram @mani_tochka_bot",
        }

    data = make_card_data(
        category=slide["category"],
        emoji=slide["emoji"],
        spent=slide["spent"],
        limit=slide["limit"],
        comment={"ops": slide["ops"], "text": slide["comment"]},
        accent_color=slide["accent"],
    )
    data["bg_uri"] = PHOTO_CARDS
    return data


def render_all(slides=None, only=None):
    slide_list = slides if slides is not None else SLIDES
    template = Template(Path("template_slide.html").read_text(encoding="utf-8"))

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1080, "height": 1920})

        for i, slide in enumerate(slide_list, start=1):
            if only is not None and i != only:
                continue

            render_data = build_render_data(slide)
            html = template.render(**render_data)
            tmp_path = Path("rendered_tmp.html")
            tmp_path.write_text(html, encoding="utf-8")

            page.goto(tmp_path.resolve().as_uri())
            out_path = OUT_DIR / f"slide_{i:02d}.png"
            page.screenshot(path=str(out_path))
            print(f"Слайд {i} готов: {out_path}")

        browser.close()

    Path("rendered_tmp.html").unlink(missing_ok=True)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("slide_number", nargs="?", type=int, default=None)
    parser.add_argument("--out-dir", dest="out_dir", default=None)
    parser.add_argument("--photo-main", dest="photo_main", default=None)
    parser.add_argument("--photo-cards", dest="photo_cards", default=None)
    parser.add_argument("--photo-goal", dest="photo_goal", default=None)
    parser.add_argument(
        "--profile",
        dest="profile",
        default=None,
        help="JSON from LLM (see prompts/carousel-budget-llm.md)",
    )
    args = parser.parse_args()

    if args.out_dir:
        OUT_DIR = Path(args.out_dir)
        OUT_DIR.mkdir(parents=True, exist_ok=True)

    if args.photo_main:
        PHOTO_SLIDE1 = Path(args.photo_main).resolve().as_uri()
    if args.photo_cards:
        PHOTO_CARDS = Path(args.photo_cards).resolve().as_uri()
    if args.photo_goal:
        PHOTO_GOAL = Path(args.photo_goal).resolve().as_uri()

    slides = SLIDES
    if args.profile:
        from budget_profile_loader import load_profile, profile_to_slides

        profile = load_profile(args.profile)
        slides = profile_to_slides(profile, PHOTO_BOT_SCREENSHOT)

    render_all(slides=slides, only=args.slide_number)
