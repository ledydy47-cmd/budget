"""Load and validate carousel budget JSON from LLM output."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CATEGORY_KEYS = (
    "housing",
    "groceries",
    "cafe",
    "marketplaces",
    "utilities",
    "transport",
    "beauty",
    "subscriptions",
    "leisure",
)

SPENT_TOLERANCE = 500


def load_profile(path: Path | str) -> dict[str, Any]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    errors = validate_profile(data)
    if errors:
        raise ValueError("Invalid budget profile:\n" + "\n".join(f"  - {e}" for e in errors))
    return data


def validate_profile(data: dict[str, Any]) -> list[str]:
    errors: list[str] = []

    income = data.get("income")
    if not isinstance(income, (int, float)) or income < 10000:
        errors.append("income must be a number >= 10000")

    categories = data.get("categories")
    if not isinstance(categories, list) or len(categories) != 9:
        errors.append("categories must be an array of exactly 9 items")
        return errors

    keys = [c.get("key") for c in categories if isinstance(c, dict)]
    if keys != list(CATEGORY_KEYS):
        errors.append(f"category keys must be {list(CATEGORY_KEYS)}, got {keys}")

    spent_sum = 0
    over = 0
    for i, cat in enumerate(categories):
        if not isinstance(cat, dict):
            errors.append(f"categories[{i}] must be an object")
            continue
        for field in ("category", "emoji", "spent", "limit", "ops", "comment", "accent"):
            if field not in cat:
                errors.append(f"categories[{i}] missing {field}")
        spent = cat.get("spent", 0)
        limit = cat.get("limit", 0)
        if isinstance(spent, (int, float)) and isinstance(limit, (int, float)):
            spent_sum += int(spent)
            if spent > limit:
                over += 1

    monthly_savings = data.get("monthly_savings")
    if monthly_savings is None and isinstance(income, (int, float)):
        monthly_savings = income - spent_sum
    if isinstance(income, (int, float)) and isinstance(monthly_savings, (int, float)):
        expected_spent = income - monthly_savings
        if abs(spent_sum - expected_spent) > SPENT_TOLERANCE:
            errors.append(
                f"sum(spent)={spent_sum} should be ~ income - monthly_savings "
                f"({income} - {monthly_savings} = {expected_spent}), tolerance {SPENT_TOLERANCE}"
            )

    if over < 1 or over > 3:
        errors.append(f"expected 1–2 categories over budget (spent > limit), got {over}")

    goal = data.get("goal")
    if not isinstance(goal, dict):
        errors.append("goal must be an object with title, saved, target")
    else:
        for field in ("title", "saved", "target"):
            if field not in goal:
                errors.append(f"goal missing {field}")

    if not data.get("intro_text"):
        errors.append("intro_text is required")

    return errors


def profile_to_slides(profile: dict[str, Any], bot_screenshot_uri: str) -> list[dict[str, Any]]:
    income = int(profile["income"])
    categories = profile["categories"]
    spent_total = sum(int(c["spent"]) for c in categories)
    monthly_savings = profile.get("monthly_savings")
    if monthly_savings is None:
        monthly_savings = income - spent_total
    else:
        monthly_savings = int(monthly_savings)

    goal = profile["goal"]
    slides: list[dict[str, Any]] = [
        {"type": "text", "text": profile["intro_text"]},
    ]

    for cat in categories:
        slides.append(
            {
                "category": cat["category"],
                "emoji": cat["emoji"],
                "spent": int(cat["spent"]),
                "limit": int(cat["limit"]),
                "accent": cat["accent"],
                "ops": int(cat["ops"]),
                "comment": cat["comment"],
            }
        )

    goal_title = goal["title"]
    try:
        goal_months = int(profile.get("goal_months", 2))
    except (TypeError, ValueError):
        goal_months = 2
    if goal_months <= 0:
        goal_months = 2
    if monthly_savings > 0:
        goal_saved = monthly_savings * goal_months
    else:
        goal_saved = int(goal["saved"])
    slides.append(
        {
            "type": "goal",
            "goal_title": goal_title,
            "goal_saved": goal_saved,
            "goal_target": int(goal["target"]),
            "income": income,
            "spent": spent_total,
            "goal_heading": profile.get("goal_heading"),
        }
    )

    slides.append(
        {
            "type": "bot_outro",
            "heading": profile.get(
                "bot_heading",
                "Все конверты веду в боте\nв тг @mani_tochka_bot 🐰",
            ),
            "bot_screenshot_uri": bot_screenshot_uri,
            "caption": profile.get(
                "bot_caption",
                "Каждый месяц вижу, как мечта становится ближе ✈️💗",
            ),
        }
    )

    return slides


def main() -> None:
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Validate carousel budget profile JSON")
    parser.add_argument("profile", type=Path)
    args = parser.parse_args()

    try:
        data = json.loads(args.profile.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    errors = validate_profile(data)
    if errors:
        for err in errors:
            print(f"ERROR: {err}")
        sys.exit(1)

    spent = sum(int(c["spent"]) for c in data["categories"])
    print(f"OK: income={data['income']}, sum(spent)={spent}, categories=9")


if __name__ == "__main__":
    main()
