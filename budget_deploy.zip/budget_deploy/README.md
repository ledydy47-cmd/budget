---
title: Carousel Studio
emoji: 🖼
colorFrom: pink
colorTo: purple
sdk: docker
app_port: 7860
pinned: false
---

# Carousel Studio — генератор карусели «Бюджет»

Flask + Playwright. Каждый слайд рендерится headless-браузером в PNG 1080×1920.
