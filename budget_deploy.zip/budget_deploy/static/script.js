let currentProject = null;

const tabsEl = document.querySelectorAll(".tab-btn");
const slotsContainer = document.getElementById("slots-container");
const generateBtn = document.getElementById("generate-btn");
const saveBtn = document.getElementById("save-btn");
const statusLine = document.getElementById("status-line");
const gallery = document.getElementById("gallery");
const textEditorSection = document.getElementById("text-editor-section");
const slidesEditor = document.getElementById("slides-editor");
const saveTextBtn = document.getElementById("save-text-btn");
let slidesDirty = false;
const goalPhotoWrap = document.getElementById("goal-photo-wrap");
const goalPhotoBox = document.getElementById("goal-photo-box");
const coupleSection = document.getElementById("couple-section");
const placeSection = document.getElementById("place-section");
const mainActions = document.querySelector("#slots-container").nextElementSibling;
const coupleFolder = document.getElementById("couple-folder");
const coupleHint = document.getElementById("couple-hint");
const coupleScenario = document.getElementById("couple-scenario");
const couplePrompts = document.getElementById("couple-prompts");
const coupleCaption = document.getElementById("couple-caption");
const copyCaptionBtn = document.getElementById("copy-caption-btn");

let currentCoupleId = null;
let coupleHasLayout = false;
let coupleCaptionText = "";

function setStatus(text) {
  statusLine.textContent = text;
}

function isCouple(projectKey) {
  return Boolean(window.PROJECTS[projectKey] && window.PROJECTS[projectKey].kind === "couple");
}

function isPlace(projectKey) {
  return Boolean(window.PROJECTS[projectKey] && window.PROJECTS[projectKey].kind === "place");
}

function formatCaption(caption) {
  if (!caption) return "";
  const tags = (caption.hashtags || []).slice(0, 5).join(" ");
  return [caption.title || "", caption.description || "", tags].filter(Boolean).join("\n\n");
}

function renderCoupleSlots(detail) {
  slotsContainer.innerHTML = "";
  detail.slides.forEach(slide => {
    const box = document.createElement("div");
    box.className = "slot-box";
    const label = document.createElement("div");
    label.className = "slot-label";
    label.textContent = slide.label;
    box.appendChild(label);

    const takeFile = file => {
      if (file) uploadCouplePhoto(detail.id, slide.slot, file, box);
    };
    box.addEventListener("dragover", e => {
      e.preventDefault();
      box.classList.add("dragover");
    });
    box.addEventListener("dragleave", () => box.classList.remove("dragover"));
    box.addEventListener("drop", e => {
      e.preventDefault();
      box.classList.remove("dragover");
      takeFile(e.dataTransfer.files[0]);
    });
    box.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => takeFile(input.files[0]);
      input.click();
    });

    slotsContainer.appendChild(box);
    if (!slide.hasPhoto) return;
    const img = new Image();
    img.onload = () => {
      box.classList.add("has-photo");
      box.insertBefore(img, box.firstChild);
    };
    img.onerror = () => {};
    img.src = `/api/couple/photo/${detail.id}/${slide.slot}?t=${Date.now()}`;
  });
}

function uploadCouplePhoto(coupleId, slot, file, box) {
  const formData = new FormData();
  formData.append("id", coupleId);
  formData.append("slot", slot);
  formData.append("file", file);
  setStatus("Загружаю фото...");
  fetch("/api/couple/upload", { method: "POST", body: formData })
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        setStatus("Ошибка загрузки: " + (data.error || ""));
        return;
      }
      setStatus("Фото загружено");
      const existingImg = box.querySelector("img");
      if (existingImg) existingImg.remove();
      const img = document.createElement("img");
      img.src = URL.createObjectURL(file);
      box.classList.add("has-photo");
      box.insertBefore(img, box.firstChild);
    })
    .catch(err => setStatus("Ошибка сети: " + err));
}

function showCoupleDetail(detail) {
  currentCoupleId = detail.id;
  coupleHasLayout = Boolean(detail.hasLayout);
  coupleCaptionText = formatCaption(detail.caption);
  coupleScenario.textContent = detail.scenario || "";
  couplePrompts.textContent = (detail.slides || [])
    .map(slide => `${slide.label}\n${slide.photoPrompt}\nЗона для плашек: ${slide.freeZone}`)
    .join("\n\n");
  coupleCaption.textContent = coupleCaptionText;
  coupleHint.textContent = coupleHasLayout
    ? "Плашки расставлены — можно собирать."
    : "Жду расстановку плашек. Загрузи чистые фото, затем сборка откроется после layout.json.";
  generateBtn.disabled = !coupleHasLayout;
  renderCoupleSlots(detail);
}

function loadCoupleDetail(coupleId) {
  if (!coupleId) {
    currentCoupleId = null;
    slotsContainer.innerHTML = "";
    coupleScenario.textContent = "";
    couplePrompts.textContent = "";
    coupleCaption.textContent = "";
    coupleHint.textContent = "В couple_inbox пока нет папки с brief.json";
    generateBtn.disabled = true;
    return;
  }
  fetch(`/api/couple/${coupleId}`)
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        setStatus(data.error || "Не удалось открыть карусель");
        return;
      }
      showCoupleDetail(data);
    })
    .catch(err => setStatus("Ошибка сети: " + err));
}

function loadCoupleFolders() {
  fetch("/api/couple/inbox")
    .then(r => r.json())
    .then(data => {
      coupleFolder.innerHTML = "";
      const folders = data.folders || [];
      if (!folders.length) {
        loadCoupleDetail(null);
        return;
      }
      folders.forEach(folder => {
        const option = document.createElement("option");
        option.value = folder.id;
        option.textContent = folder.title;
        coupleFolder.appendChild(option);
      });
      loadCoupleDetail(folders[0].id);
    })
    .catch(err => setStatus("Ошибка сети: " + err));
}

function renderSlots(projectKey) {
  const project = window.PROJECTS[projectKey];
  slotsContainer.innerHTML = "";

  project.slots.forEach(slot => {
    const box = document.createElement("div");
    box.className = "slot-box";
    box.dataset.slot = slot.key;

    const label = document.createElement("div");
    label.className = "slot-label";
    label.textContent = slot.label;
    box.appendChild(label);

    box.addEventListener("dragover", e => {
      e.preventDefault();
      box.classList.add("dragover");
    });
    box.addEventListener("dragleave", () => box.classList.remove("dragover"));
    box.addEventListener("drop", e => {
      e.preventDefault();
      box.classList.remove("dragover");
      const file = e.dataTransfer.files[0];
      if (file) uploadPhoto(projectKey, slot.key, file, box);
    });

    box.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = () => {
        if (input.files[0]) uploadPhoto(projectKey, slot.key, input.files[0], box);
      };
      input.click();
    });

    slotsContainer.appendChild(box);

    const img = new Image();
    img.onload = () => {
      box.classList.add("has-photo");
      box.insertBefore(img, box.firstChild);
    };
    img.onerror = () => {};
    img.src = `/api/photo/${projectKey}/${slot.key}?t=${Date.now()}`;
  });
}

function uploadPhoto(projectKey, slotKey, file, box) {
  const formData = new FormData();
  formData.append("project", projectKey);
  formData.append("slot", slotKey);
  formData.append("file", file);

  setStatus("Загружаю фото...");
  fetch("/api/upload", { method: "POST", body: formData })
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        setStatus("Ошибка загрузки: " + (data.error || ""));
        return;
      }
      setStatus("Фото загружено");
      const existingImg = box.querySelector("img");
      if (existingImg) existingImg.remove();
      const img = document.createElement("img");
      img.src = URL.createObjectURL(file);
      box.classList.add("has-photo");
      box.insertBefore(img, box.firstChild);
    })
    .catch(err => setStatus("Ошибка сети: " + err));
}

function loadTextEditor(projectKey) {
  const project = window.PROJECTS[projectKey];
  if (!project.slides_config) {
    textEditorSection.style.display = "none";
    return;
  }
  fetch(`/api/slides/${projectKey}`)
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        textEditorSection.style.display = "none";
        return;
      }
      slidesEditor.value = data.content;
      slidesDirty = false;
      updatePostPreview();
      if (goalPhotoWrap) goalPhotoWrap.style.display = projectKey === "budget" ? "grid" : "none";
      refreshGoalPhotoPreview(projectKey);
      textEditorSection.style.display = "block";
    })
    .catch(() => { textEditorSection.style.display = "none"; });
}

slidesEditor.addEventListener("input", () => {
  slidesDirty = true;
});

saveTextBtn.addEventListener("click", () => {
  if (!currentProject) return;
  setStatus("Сохраняю текст...");
  fetch(`/api/slides/${currentProject}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content: slidesEditor.value }),
  })
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        setStatus("Ошибка: " + (data.error || ""));
        return;
      }
      slidesDirty = false;
      updatePostPreview();
      if (data.title) {
        const tabBtn = document.querySelector(`.tab-btn[data-project="${currentProject}"]`);
        if (tabBtn) tabBtn.textContent = data.title;
        if (window.PROJECTS[currentProject]) window.PROJECTS[currentProject].title = data.title;
      }
      setStatus("Текст сохранён. Теперь нажмите «Сгенерировать карусель»");
    })
    .catch(err => setStatus("Ошибка сети: " + err));
});

coupleFolder.addEventListener("change", () => {
  gallery.innerHTML = "";
  saveBtn.disabled = true;
  loadCoupleDetail(coupleFolder.value);
});

copyCaptionBtn.addEventListener("click", () => {
  if (!coupleCaptionText) return;
  navigator.clipboard.writeText(coupleCaptionText)
    .then(() => setStatus("Подпись скопирована"))
    .catch(() => setStatus("Не удалось скопировать"));
});

tabsEl.forEach(btn => {
  btn.addEventListener("click", () => {
    tabsEl.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentProject = btn.dataset.project;
    gallery.innerHTML = "";
    saveBtn.disabled = true;
    setStatus("");
    if (isPlace(currentProject)) {
      textEditorSection.style.display = "none";
      coupleSection.style.display = "none";
      placeSection.style.display = "block";
      slotsContainer.innerHTML = "";
      mainActions.style.display = "none";
      return;
    }
    placeSection.style.display = "none";
    mainActions.style.display = "flex";
    if (isCouple(currentProject)) {
      textEditorSection.style.display = "none";
      coupleSection.style.display = "block";
      generateBtn.textContent = "Собрать карусель";
      generateBtn.disabled = true;
      loadCoupleFolders();
      return;
    }
    coupleSection.style.display = "none";
    generateBtn.textContent = "Сгенерировать карусель";
    generateBtn.disabled = false;
    renderSlots(currentProject);
    loadTextEditor(currentProject);
  });
});

generateBtn.addEventListener("click", () => {
  if (!currentProject) {
    setStatus("Сначала выберите карусель");
    return;
  }
  if (isCouple(currentProject)) {
    if (!currentCoupleId || !coupleHasLayout) {
      setStatus("жду расстановку плашек");
      return;
    }
    setStatus("Собираю слайды, это может занять до минуты...");
    generateBtn.disabled = true;
    gallery.innerHTML = "";
    fetch("/api/couple/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: currentCoupleId }),
    })
      .then(r => r.json())
      .then(data => {
        generateBtn.disabled = !coupleHasLayout;
        if (!data.ok) {
          setStatus(data.error || "Ошибка сборки");
          return;
        }
        if (data.caption) {
          coupleCaptionText = data.caption.trim();
          coupleCaption.textContent = coupleCaptionText;
        }
        setStatus(`Готово! Слайдов: ${data.slides.length}`);
        data.slides.forEach(url => {
          const img = document.createElement("img");
          img.src = url;
          gallery.appendChild(img);
        });
        saveBtn.disabled = true;
      })
      .catch(err => {
        generateBtn.disabled = !coupleHasLayout;
        setStatus("Ошибка сети: " + err);
      });
    return;
  }
  if (slidesDirty && textEditorSection.style.display !== "none") {
    setStatus("Сохраняю правки редактора...");
    fetch(`/api/slides/${currentProject}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: slidesEditor.value }),
    })
      .then(r => r.json())
      .then(res => {
        if (!res.ok) {
          setStatus("Не сохранено: " + (res.error || "") + " — карусель не генерирую");
          return;
        }
        slidesDirty = false;
        updatePostPreview();
        if (res.title) {
          const tabBtn = document.querySelector(`.tab-btn[data-project="${currentProject}"]`);
          if (tabBtn) tabBtn.textContent = res.title;
        }
        generateBtn.click();
      })
      .catch(err => setStatus("Ошибка сети: " + err));
    return;
  }
  setStatus("Генерирую слайды, это может занять до минуты...");
  generateBtn.disabled = true;
  gallery.innerHTML = "";

  fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ project: currentProject }),
  })
    .then(r => r.json())
    .then(data => {
      generateBtn.disabled = false;
      if (!data.ok) {
        setStatus("Ошибка генерации: " + (data.error || ""));
        return;
      }
      setStatus(`Готово! Слайдов: ${data.slides.length}`);
      data.slides.forEach(url => {
        const img = document.createElement("img");
        img.src = url;
        gallery.appendChild(img);
      });
      saveBtn.disabled = false;
    })
    .catch(err => {
      generateBtn.disabled = false;
      setStatus("Ошибка сети: " + err);
    });
});

saveBtn.addEventListener("click", () => {
  fetch("/api/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ project: currentProject }),
  })
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        setStatus("Ошибка сохранения: " + (data.error || ""));
        return;
      }
      setStatus("Сохранено в: " + data.path);
    })
    .catch(err => setStatus("Ошибка сети: " + err));
});

if (tabsEl.length > 0) {
  tabsEl[0].click();
}

function refreshGoalPhotoPreview(projectKey) {
  if (!goalPhotoBox) return;
  goalPhotoBox.querySelectorAll("img").forEach(img => img.remove());
  goalPhotoBox.classList.remove("has-photo");
  let file = "";
  try {
    const parsed = JSON.parse(slidesEditor.value);
    if (parsed && typeof parsed.goal_photo === "string") file = parsed.goal_photo.trim();
  } catch (e) { file = ""; }
  const img = new Image();
  img.onload = () => {
    goalPhotoBox.classList.add("has-photo");
    goalPhotoBox.insertBefore(img, goalPhotoBox.firstChild);
  };
  img.onerror = () => goalPhotoBox.classList.remove("has-photo");
  img.src = file
    ? `/api/goal-photo/${projectKey}?file=${encodeURIComponent(file)}&t=${Date.now()}`
    : `/api/goal-photo/${projectKey}?t=${Date.now()}`;
}

function uploadGoalPhoto(projectKey, file) {
  const formData = new FormData();
  formData.append("file", file);
  setStatus("Загружаю фото мечты...");
  fetch(`/api/goal-photo/${projectKey}`, { method: "POST", body: formData })
    .then(r => r.json())
    .then(data => {
      if (!data.ok) {
        setStatus("Ошибка загрузки: " + (data.error || ""));
        return;
      }
      try {
        const parsed = JSON.parse(slidesEditor.value);
        parsed.goal_photo = data.file;
        slidesEditor.value = JSON.stringify(parsed, null, 2);
        slidesDirty = true;
      } catch (e) {
        setStatus("Фото загружено, но JSON в редакторе не разобрать — добавь goal_photo вручную");
        return;
      }
      refreshGoalPhotoPreview(projectKey);
      setStatus("Фото загружено и записано в JSON. Нажми «Сгенерировать карусель»");
    })
    .catch(err => setStatus("Ошибка сети: " + err));
}

if (goalPhotoBox) {
  goalPhotoBox.addEventListener("click", () => {
    if (!currentProject) return;
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = () => {
      if (input.files[0]) uploadGoalPhoto(currentProject, input.files[0]);
    };
    input.click();
  });
  goalPhotoBox.addEventListener("dragover", e => {
    e.preventDefault();
    goalPhotoBox.classList.add("dragover");
  });
  goalPhotoBox.addEventListener("dragleave", () => goalPhotoBox.classList.remove("dragover"));
  goalPhotoBox.addEventListener("drop", e => {
    e.preventDefault();
    goalPhotoBox.classList.remove("dragover");
    const file = e.dataTransfer.files[0];
    if (file && currentProject) uploadGoalPhoto(currentProject, file);
  });
}

/* --- Превью заголовка и описания поста --- */
function updatePostPreview() {
  var wrap = document.getElementById("post-preview");
  if (!wrap) return;
  var data = null;
  try { data = JSON.parse(slidesEditor.value); } catch (err) { data = null; }
  var title = data && typeof data.post_title === "string" ? data.post_title.trim() : "";
  var caption = data && typeof data.post_caption === "string" ? data.post_caption.trim() : "";
  var query = data && typeof data.goal_photo_query === "string" ? data.goal_photo_query.trim() : "";
  document.getElementById("post-title-box").textContent = title;
  document.getElementById("post-caption-box").textContent = caption;
  document.getElementById("photo-query-box").textContent = query;
  wrap.style.display = (title || caption || query) ? "block" : "none";
}

function copyPostText(text, btn) {
  if (!text) return;
  var done = function () {
    var old = btn.textContent;
    btn.textContent = "Скопировано";
    setTimeout(function () { btn.textContent = old; }, 1200);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done, function () {});
  }
}

(function () {
  var map = [["copy-post-title", "post-title-box"],
             ["copy-post-caption", "post-caption-box"],
             ["copy-photo-query", "photo-query-box"]];
  map.forEach(function (pair) {
    var btn = document.getElementById(pair[0]);
    var box = document.getElementById(pair[1]);
    if (!btn || !box) return;
    btn.addEventListener("click", function () { copyPostText(box.textContent, btn); });
  });
  setTimeout(updatePostPreview, 600);
})();
