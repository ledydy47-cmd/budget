const CANVAS_W = 1080
const CANVAS_H = 1920
const VIEW_W = 390

const placePhotos = document.getElementById("place-photos")
const placePhotoNames = document.getElementById("place-photo-names")
const placeData = document.getElementById("place-data")
const placeBuildBtn = document.getElementById("place-build-btn")
const placeAddTextBtn = document.getElementById("place-add-text-btn")
const placeRenderBtn = document.getElementById("place-render-btn")
const placeDownloadBtn = document.getElementById("place-download-btn")
const placeSwitcher = document.getElementById("place-switcher")
const placeStageWrap = document.getElementById("place-stage-wrap")

const board = {
  photos: [],
  slides: [],
  active: 0,
  outputId: null,
  selected: null,
}

let spaceHeld = false

function money(value) {
  return `${Math.round(value).toLocaleString("ru-RU")} ₽`
}

function plural(n, one, few, many) {
  const n100 = Math.abs(n) % 100
  const n10 = n100 % 10
  if (n100 >= 11 && n100 <= 14) return many
  if (n10 === 1) return one
  if (n10 >= 2 && n10 <= 4) return few
  return many
}

function typo(scale) {
  const s = scale
  return {
    icon: Math.round(32 * s),
    name: Math.round(15 * s),
    pencil: Math.round(36 * s),
    spent: Math.round(20 * s),
    meta: Math.round(16 * s),
    foot: Math.round(12 * s),
    bar: Math.max(8, Math.round(10 * s)),
    pad: Math.round(16 * s),
    gap: Math.round(12 * s),
    title: Math.round(14 * s),
    sub: Math.round(12 * s),
    amt: Math.round(14 * s),
  }
}

function parseAmount(raw) {
  const numeric = Number(String(raw).replace(/\s/g, "").replace(",", "."))
  if (!Number.isFinite(numeric)) {
    throw new Error(`Не поняла сумму «${raw}»`)
  }
  return Math.round(numeric)
}

function splitEmoji(value) {
  const match = value.match(/^(\p{Extended_Pictographic}\uFE0F?(?:\u200D\p{Extended_Pictographic}\uFE0F?)*)\s+(.+)$/u)
  if (!match) return { emoji: "💸", title: value }
  return { emoji: match[1], title: match[2] }
}

function categoryBar(name) {
  const text = name.toLowerCase()
  if (text.includes("аренд") || text.includes("жиль")) return "oklch(0.68 0.12 140)"
  if (text.includes("продукт")) return "oklch(0.72 0.14 45)"
  if (text.includes("кафе") || text.includes("достав")) return "oklch(0.72 0.13 355)"
  if (text.includes("космет") || text.includes("уход")) return "oklch(0.68 0.12 160)"
  if (text.includes("игр")) return "oklch(0.68 0.13 280)"
  return "oklch(0.78 0.115 355)"
}

function parseBoard(text) {
  const slides = new Map()
  let current = null
  text.split(/\n/).forEach((raw, index) => {
    const line = raw.trim()
    if (!line || line.startsWith("#")) return
    const slideNo = line.match(/^(?:слайд\s*)?(\d+)\s*$/i)
    if (slideNo) {
      current = Number(slideNo[1])
      if (!slides.has(current)) slides.set(current, [])
      return
    }
    if (!current) {
      throw new Error(`Строка ${index + 1}: сначала напиши номер слайда, например 1`)
    }
    const typed = line.match(/^(текст|плашка|доход|категория)\s*:\s*(.+)$/i)
    if (!typed) {
      throw new Error(`Строка ${index + 1}: нужна метка текст, плашка, доход или категория`)
    }
    const kind = typed[1].toLowerCase()
    const parts = typed[2].split("|").map(part => part.trim()).filter(Boolean)
    slides.get(current).push({ kind, parts, line: index + 1 })
  })
  return slides
}

function itemFromRow(row, index) {
  if (row.kind === "текст" || row.kind === "плашка") {
    return {
      type: row.kind === "плашка" ? "box" : "text",
      lines: row.parts.length ? row.parts : ["текст"],
      x: 540,
      y: 260 + index * 140,
      size: 52,
    }
  }
  if (row.kind === "доход") {
    if (row.parts.length < 3) {
      throw new Error(`Строка ${row.line}: доход: эмодзи Название | подпись | сумма`)
    }
    const { emoji, title } = splitEmoji(row.parts[0])
    return {
      type: "transaction",
      x: index % 2 === 0 ? 36 : 400,
      y: 420 + index * 200,
      w: 640,
      h: 150,
      scale: 2,
      app: {
        kind: "transaction",
        icon: emoji,
        title,
        subtitle: row.parts[1],
        amount: parseAmount(row.parts[2]),
        type: "income",
      },
    }
  }
  if (row.parts.length < 3) {
    throw new Error(`Строка ${row.line}: категория: эмодзи Название | потрачено | лимит`)
  }
  const { emoji, title } = splitEmoji(row.parts[0])
  return {
    type: "category",
    x: index % 2 === 0 ? 28 : 400,
    y: 340 + index * 340,
    w: 660,
    h: 300,
    scale: 1.45,
    app: {
      kind: "category",
      emoji,
      name: title,
      spent: parseAmount(row.parts[1]),
      limit: parseAmount(row.parts[2]),
      ops: row.parts[3] ? parseAmount(row.parts[3]) : 1,
      daysLeft: row.parts[4] ? parseAmount(row.parts[4]) : 3,
      bar: categoryBar(title),
    },
  }
}

function categoryHtml(item) {
  const app = item.app
  const t = typo(item.scale)
  const over = app.spent > app.limit
  const remain = Math.abs(app.limit - app.spent)
  const percent = app.limit > 0 ? Math.min(100, Math.round((app.spent / app.limit) * 100)) : 100
  const status = over
    ? `<span class="bad"> · превышение на ${money(remain)}</span>`
    : `<span class="ok"> · осталось ${money(Math.max(0, app.limit - app.spent))}</span>`
  const barColor = over ? "oklch(0.63 0.19 20)" : app.bar
  return `<div class="place-card" style="padding:${t.pad}px;gap:${t.gap}px">
    <div class="head" style="gap:${t.gap}px">
      <span style="font-size:${t.icon}px;line-height:1">${app.emoji}</span>
      <span class="name" style="font-size:${t.name}px">${escapeHtml(app.name)}</span>
      <span class="pencil" style="width:${t.pencil}px;height:${t.pencil}px"></span>
    </div>
    <p class="amounts" style="margin-top:${t.gap}px;font-size:${t.meta}px">
      <span class="spent" style="font-size:${t.spent}px">${money(app.spent)}</span><span class="limit"> / ${money(app.limit)}</span>${status}
    </p>
    <div class="bar" style="margin-top:${t.gap}px;height:${t.bar}px"><i style="width:${over ? 100 : percent}%;background:${barColor}"></i></div>
    <div class="foot" style="margin-top:${t.gap}px;font-size:${t.foot}px">
      <span>${app.ops} ${plural(app.ops, "операция", "операции", "операций")}</span>
      <span>осталось ${app.daysLeft} ${plural(app.daysLeft, "день", "дня", "дней")}</span>
    </div>
  </div>`
}

function transactionHtml(item) {
  const app = item.app
  const t = typo(item.scale)
  return `<div class="place-tx" style="padding:${t.pad}px;gap:${t.gap}px">
    <span style="font-size:${t.icon}px;line-height:1">${app.icon}</span>
    <div class="meta">
      <div class="title" style="font-size:${t.title}px">${escapeHtml(app.title)}</div>
      <div class="sub" style="font-size:${t.sub}px">${escapeHtml(app.subtitle)}</div>
    </div>
    <div class="amt" style="font-size:${t.amt}px">+${money(app.amount)}</div>
  </div>`
}

function setStatus(text) {
  const line = document.getElementById("status-line")
  if (line) line.textContent = text
}

function stageScale() {
  return VIEW_W / CANVAS_W
}

function renderBoard() {
  placeSwitcher.innerHTML = ""
  placeStageWrap.innerHTML = ""
  board.slides.forEach((slide, index) => {
    const tab = document.createElement("button")
    tab.type = "button"
    tab.className = `secondary-btn${index === board.active ? " active" : ""}`
    tab.textContent = String(index + 1)
    tab.addEventListener("click", () => {
      board.active = index
      renderBoard()
    })
    placeSwitcher.appendChild(tab)
  })

  const slide = board.slides[board.active]
  if (!slide) return

  const viewport = document.createElement("div")
  viewport.className = "place-viewport"
  const stage = document.createElement("div")
  stage.className = "place-stage"
  stage.style.transform = `scale(${stageScale()})`
  const image = document.createElement("img")
  image.className = "place-bg"
  image.draggable = false
  image.src = slide.photoUrl
  stage.appendChild(image)

  slide.items.forEach(item => {
    const node = item.type === "text" || item.type === "box" ? textNode(item) : cardNode(item)
    item._node = node
    if (item === board.selected) node.classList.add("selected")
    stage.appendChild(node)
  })

  stage.addEventListener("pointerdown", event => {
    if (!spaceHeld) return
    if (event.target.closest(".place-handle, .place-x")) return
    const onCard = event.target.closest(".place-item") && !event.target.closest(".place-text, .place-box")
    if (onCard) return
    const item = textUnderPointer(event) || selectedText() || firstText()
    if (!item?._node) return
    event.preventDefault()
    event.stopPropagation()
    selectItem(item)
    const start = { x: item.x, y: item.y }
    trackPointer(event, (dx, dy) => {
      item.x = start.x + dx
      item.y = start.y + dy
      applyTextPosition(item._node, item)
    })
  }, true)

  viewport.appendChild(stage)
  placeStageWrap.appendChild(viewport)
}

function textNode(item) {
  const node = document.createElement("div")
  node.className = item.type === "box" ? "place-box place-item" : "place-text place-item"
  node.innerHTML = item.lines.map(line => `<div>${escapeHtml(line)}</div>`).join("")
  applyTextPosition(node, item)
  node.appendChild(removeButton(item))
  addHandles(node)
  bindDrag(node, item, (start, dx, dy) => {
    item.x = start.x + dx
    item.y = start.y + dy
    applyTextPosition(node, item)
  })
  bindTextResize(node, item)
  node.addEventListener("dblclick", event => {
    event.stopPropagation()
    const next = window.prompt("Текст, новая строка через |", item.lines.join(" | "))
    if (next == null) return
    item.lines = next.split("|").map(part => part.trim()).filter(Boolean)
    if (!item.lines.length) item.lines = ["текст"]
    renderBoard()
  })
  return node
}

function cardNode(item) {
  const node = document.createElement("div")
  node.className = "place-item"
  node.style.left = `${item.x}px`
  node.style.top = `${item.y}px`
  node.style.width = `${item.w}px`
  node.style.height = `${item.h}px`
  node.innerHTML = item.type === "category" ? categoryHtml(item) : transactionHtml(item)
  node.appendChild(removeButton(item))
  addHandles(node)
  bindDrag(node, item, (start, dx, dy) => {
    item.x = Math.round(start.x + dx)
    item.y = Math.round(start.y + dy)
    node.style.left = `${item.x}px`
    node.style.top = `${item.y}px`
  })
  bindCardResize(node, item)
  return node
}

function removeButton(item) {
  const button = document.createElement("button")
  button.type = "button"
  button.className = "place-x"
  button.textContent = "×"
  button.addEventListener("pointerdown", event => event.stopPropagation())
  button.addEventListener("click", event => {
    event.stopPropagation()
    const slide = board.slides[board.active]
    slide.items = slide.items.filter(entry => entry !== item)
    renderBoard()
  })
  return button
}

function applyTextPosition(node, item) {
  const lineHeight = item.size * 1.2
  node.style.left = `${item.x}px`
  node.style.top = `${item.y - lineHeight / 2}px`
  node.style.fontSize = `${item.size}px`
  if (item.type === "box") {
    node.style.padding = `${Math.round(item.size * 0.16)}px ${Math.round(item.size * 0.45)}px`
    node.style.borderRadius = `${Math.round(item.size * 0.3)}px`
  }
}

function selectItem(item) {
  board.selected = item
  document.querySelectorAll(".place-item.selected").forEach(el => el.classList.remove("selected"))
  if (item?._node) item._node.classList.add("selected")
}

function textUnderPointer(event) {
  const host = event.target.closest(".place-text, .place-box")
  if (!host) return null
  const slide = board.slides[board.active]
  return slide?.items.find(entry => entry._node === host) || null
}

function selectedText() {
  const item = board.selected
  if (item && (item.type === "text" || item.type === "box")) return item
  return null
}

function firstText() {
  const slide = board.slides[board.active]
  return slide?.items.find(entry => entry.type === "text" || entry.type === "box") || null
}

function addHandles(node) {
  for (const dir of ["n", "e", "s", "w"]) {
    const handle = document.createElement("div")
    handle.className = `place-handle place-handle-${dir}`
    handle.dataset.dir = dir
    node.appendChild(handle)
  }
}

function trackPointer(event, onMove) {
  event.preventDefault()
  const scale = stageScale()
  const originX = event.clientX
  const originY = event.clientY
  const moving = ev => {
    onMove((ev.clientX - originX) / scale, (ev.clientY - originY) / scale)
  }
  const up = () => {
    window.removeEventListener("pointermove", moving)
    window.removeEventListener("pointerup", up)
  }
  window.addEventListener("pointermove", moving)
  window.addEventListener("pointerup", up)
}

function bindDrag(node, item, onMove) {
  node.addEventListener("pointerdown", event => {
    if (event.target.closest(".place-x, .place-handle")) return
    if (spaceHeld && (item.type === "text" || item.type === "box")) return
    selectItem(item)
    const start = { x: item.x, y: item.y }
    trackPointer(event, (dx, dy) => onMove(start, dx, dy))
  })
}

function resizeText(item, dir, start, dx, dy) {
  const lines = Math.max(item.lines.length, 1)
  const lineHeight = size => size * 1.2
  let factor = 1
  if (dir === "e") factor = (start.w + dx) / start.w
  if (dir === "w") factor = (start.w - dx) / start.w
  if (dir === "s") factor = (start.h + dy) / start.h
  if (dir === "n") factor = (start.h - dy) / start.h
  factor = Math.min(180 / start.size, Math.max(24 / start.size, factor))
  item.size = Math.max(24, Math.round(start.size * factor))
  const grown = item.size / start.size
  const newW = start.w * grown
  if (dir === "e") item.x = start.x - start.w / 2 + newW / 2
  if (dir === "w") item.x = start.x + start.w / 2 - newW / 2
  if (dir === "e" || dir === "w") {
    const center = start.y + (lines - 1) * lineHeight(start.size) / 2
    item.y = center - (lines - 1) * lineHeight(item.size) / 2
  }
  if (dir === "s") {
    const top = start.y - lineHeight(start.size) / 2
    item.y = top + lineHeight(item.size) / 2
    item.x = start.x
  }
  if (dir === "n") {
    const bottom = start.y - lineHeight(start.size) / 2 + lines * lineHeight(start.size)
    item.y = bottom - lines * lineHeight(item.size) + lineHeight(item.size) / 2
    item.x = start.x
  }
}

function bindTextResize(node, item) {
  node.querySelectorAll(".place-handle").forEach(handle => {
    handle.addEventListener("pointerdown", event => {
      event.stopPropagation()
      selectItem(item)
      const start = {
        size: item.size,
        x: item.x,
        y: item.y,
        w: Math.max(node.offsetWidth, 1),
        h: Math.max(node.offsetHeight, 1),
      }
      trackPointer(event, (dx, dy) => {
        resizeText(item, handle.dataset.dir, start, dx, dy)
        applyTextPosition(node, item)
      })
    })
  })
}

function resizeCard(item, dir, start, dx, dy) {
  let factor = 1
  if (dir === "e") factor = (start.w + dx) / start.w
  if (dir === "w") factor = (start.w - dx) / start.w
  if (dir === "s") factor = (start.h + dy) / start.h
  if (dir === "n") factor = (start.h - dy) / start.h
  factor = Math.min(1080 / start.w, Math.max(240 / start.w, factor))
  item.w = Math.round(start.w * factor)
  item.h = Math.round(start.h * factor)
  item.scale = Math.round(start.scale * factor * 100) / 100
  if (dir === "e") item.x = start.x
  if (dir === "w") item.x = Math.round(start.x + start.w - item.w)
  if (dir === "s") item.y = start.y
  if (dir === "n") item.y = Math.round(start.y + start.h - item.h)
}

function paintCard(node, item) {
  node.style.left = `${item.x}px`
  node.style.top = `${item.y}px`
  node.style.width = `${item.w}px`
  node.style.height = `${item.h}px`
  const holder = document.createElement("div")
  holder.innerHTML = item.type === "category" ? categoryHtml(item) : transactionHtml(item)
  node.querySelector(":scope > .place-card, :scope > .place-tx").replaceWith(holder.firstElementChild)
}

function bindCardResize(node, item) {
  node.querySelectorAll(".place-handle").forEach(handle => {
    handle.addEventListener("pointerdown", event => {
      event.stopPropagation()
      selectItem(item)
      const start = { x: item.x, y: item.y, w: item.w, h: item.h, scale: item.scale }
      trackPointer(event, (dx, dy) => {
        resizeCard(item, handle.dataset.dir, start, dx, dy)
        paintCard(node, item)
      })
    })
  })
}

function typingTarget(target) {
  const tag = target?.tagName
  return tag === "TEXTAREA" || tag === "INPUT" || target?.isContentEditable
}

function placeOpen() {
  const section = document.getElementById("place-section")
  return section && section.style.display !== "none"
}

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
}

function readPhotos() {
  const files = [...(placePhotos.files || [])]
  board.photos.forEach(photo => URL.revokeObjectURL(photo.url))
  board.photos = files.map(file => ({ file, url: URL.createObjectURL(file), name: file.name }))
  placePhotoNames.textContent = board.photos.length
    ? board.photos.map((photo, index) => `${index + 1}. ${photo.name}`).join("  ·  ")
    : "Фото ещё не выбраны"
}

function buildBoard() {
  if (!board.photos.length) {
    setStatus("Сначала загрузи фото")
    return
  }
  let parsed
  try {
    parsed = parseBoard(placeData.value)
  } catch (error) {
    setStatus(error.message)
    return
  }
  const maxSlide = Math.max(board.photos.length, ...parsed.keys(), 0)
  if ([...parsed.keys()].some(number => number > board.photos.length)) {
    setStatus("В данных есть слайд, для которого нет фото")
    return
  }
  board.slides = board.photos.map((photo, index) => {
    const rows = parsed.get(index + 1) || []
    let items = []
    try {
      items = rows.map(itemFromRow)
    } catch (error) {
      setStatus(error.message)
      items = null
    }
    return { photoUrl: photo.url, file: photo.file, items }
  })
  if (board.slides.some(slide => slide.items == null)) return
  board.active = 0
  board.selected = null
  renderBoard()
  setStatus("Плашки поставлены. Текст двигай с зажатым пробелом, размер — за точки по краям.")
  void maxSlide
}

function addText() {
  const slide = board.slides[board.active]
  if (!slide) {
    setStatus("Сначала поставь плашки")
    return
  }
  const item = {
    type: "text",
    lines: ["текст"],
    x: 540,
    y: 480,
    size: 56,
  }
  slide.items.push(item)
  board.selected = item
  renderBoard()
}

function layoutPayload() {
  return {
    slides: board.slides.map((slide, index) => ({
      photo: `photos/${String(index + 1).padStart(2, "0")}.png`,
      label: String(index + 1).padStart(2, "0"),
      watermark: false,
      boxes: slide.items.filter(item => item.type === "box").map(item => ({
        lines: item.lines,
        y: Math.round(item.y),
        size: item.size,
      })),
      texts: slide.items.filter(item => item.type === "text").map(item => ({
        lines: item.lines,
        x: Math.round(item.x),
        y: Math.round(item.y),
        size: item.size,
      })),
      cards: slide.items.filter(item => item.type === "category" || item.type === "transaction").map(item => ({
        x: Math.round(item.x),
        y: Math.round(item.y),
        w: item.w,
        h: item.h,
        scale: item.scale,
        app: item.app,
      })),
    })),
  }
}

function renderPng() {
  if (!board.slides.length) {
    setStatus("Сначала поставь плашки")
    return
  }
  const form = new FormData()
  form.append("layout", JSON.stringify(layoutPayload()))
  board.slides.forEach((slide, index) => form.append(`photo_${index}`, slide.file))
  setStatus("Собираю PNG, это может занять до минуты...")
  placeRenderBtn.disabled = true
  fetch("/api/place/render", { method: "POST", body: form })
    .then(response => response.json())
    .then(data => {
      placeRenderBtn.disabled = false
      if (!data.ok) {
        setStatus(data.error || "Не удалось собрать")
        return
      }
      const gallery = document.getElementById("gallery")
      gallery.innerHTML = ""
      data.slides.forEach(url => {
        const image = document.createElement("img")
        image.src = url
        gallery.appendChild(image)
      })
      board.outputId = data.id
      if (placeDownloadBtn) placeDownloadBtn.disabled = false
      setStatus(`Готово, слайдов: ${data.slides.length}. Нажми «Скачать фото» — придёт архив.`)
    })
    .catch(error => {
      placeRenderBtn.disabled = false
      setStatus(`Ошибка сети: ${error}`)
    })
}

window.addEventListener("keydown", event => {
  if (event.code !== "Space" || !placeOpen() || typingTarget(event.target)) return
  event.preventDefault()
  spaceHeld = true
  placeStageWrap?.classList.add("place-space")
})

window.addEventListener("keyup", event => {
  if (event.code !== "Space") return
  spaceHeld = false
  placeStageWrap?.classList.remove("place-space")
})

window.addEventListener("blur", () => {
  spaceHeld = false
  placeStageWrap?.classList.remove("place-space")
})

if (placePhotos) {
  placePhotos.addEventListener("change", readPhotos)
  placeBuildBtn.addEventListener("click", buildBoard)
  placeAddTextBtn.addEventListener("click", addText)
  placeRenderBtn.addEventListener("click", renderPng)
  placeDownloadBtn.addEventListener("click", () => {
    if (!board.outputId) return
    const link = document.createElement("a")
    link.href = `/api/place/download/${board.outputId}`
    link.download = "plashki.zip"
    document.body.appendChild(link)
    link.click()
    link.remove()
  })
}
